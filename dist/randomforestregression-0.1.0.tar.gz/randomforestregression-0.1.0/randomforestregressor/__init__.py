"""Top-level package for RandomForestRegressor."""

__author__ = """Abhishek R"""
__email__ = 'abhishekraju@pluto7.com'
__version__ = '0.1.0'
